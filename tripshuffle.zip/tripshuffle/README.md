# TripShuffle

TripShuffle is a zero-dependency, GitHub Pages-ready travel planner inspired by the core interaction patterns of modern itinerary apps.

## What this prototype does

- Day-by-day itinerary planning
- Destination switching with presets + fallback destinations
- Explore/search places and add them to a day
- Budget dashboard
- Packing checklist
- Map-style route visualization
- Route-optimization interaction
- Responsive desktop/mobile layout
- **Surprise Me** engine that personalizes the itinerary using interests, pace, and budget

The planner is intentionally independent of Wanderlog branding/source/assets. It is a fresh implementation inspired by the feature set described publicly by Wanderlog, including itinerary + map, route optimization, recommendations, collaboration concepts, budgeting, reservations, checklists, and AI assistance.

## Run locally

No build step required. Open `index.html` in a browser, or serve the folder with any static server.

## GitHub Pages

Push the repository to GitHub, then use **Settings → Pages → Deploy from a branch** and select the `main` branch and `/ (root)`.

## Production roadmap

For a real-world version, replace the preset place data with API-backed destination search, place details, opening hours, real routing, weather, lodging/flight data, authentication, cloud-saved trips, and an AI itinerary service. Keep API keys and privileged calls on a server/serverless function instead of in browser JavaScript.
